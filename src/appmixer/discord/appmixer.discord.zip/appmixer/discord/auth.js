'use strict';

module.exports = {
    type: 'apiKey',
    definition: {
        auth: {
            botToken: {
                type: 'password',
                name: 'Bot Token',
                tooltip: 'Go to the Discord Developer Portal, select your application, go to the Bot section, and copy the Bot Token.'
            }
        },

        async requestProfileInfo(context) {
            // Discord API: Get current bot user
            const url = 'https://discord.com/api/v10/users/@me';
            const headers = {
                'Authorization': `Bot ${context.botToken}`
            };
            const response = await context.httpRequest({ url, method: 'GET', headers });
            if (response.data && response.data.id) {
                return { key: response.data.id };
            } else {
                throw new Error('Could not fetch bot user info from Discord.');
            }
        },
        accountNameFromProfileInfo: 'key',

        async validate(context) {
            // Validate by fetching the bot user
            const url = 'https://discord.com/api/v10/users/@me';
            const headers = {
                'Authorization': `Bot ${context.botToken}`
            };
            const response = await context.httpRequest({ url, method: 'GET', headers });
            if (response.data && response.data.id) {
                return true;
            } else {
                throw new Error('Invalid Discord Bot Token.');
            }
        }
    }
};
