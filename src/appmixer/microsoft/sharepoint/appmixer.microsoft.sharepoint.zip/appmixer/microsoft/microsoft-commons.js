'use strict';
const request = require('request-promise');

const BASE_URL = 'https://graph.microsoft.com/v1.0';

module.exports = {

    request(endpoint, method, accessToken, qs, body) {

        const url = endpoint.indexOf('https://') > -1 ? endpoint : BASE_URL + endpoint;

        return request({
            method,
            url,
            auth: { bearer: accessToken },
            qs,
            json: true,
            body,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        });
    },

    post(endpoint, accessToken, body) {

        return this.request(endpoint, 'POST', accessToken, undefined, body);
    },

    put(endpoint, accessToken, body) {

        return this.request(endpoint, 'PUT', accessToken, undefined, body);
    },

    patch(endpoint, accessToken, body) {

        return this.request(endpoint, 'PATCH', accessToken, undefined, body);
    },

    get(endpoint, accessToken, qs) {

        return this.request(endpoint, 'GET', accessToken, qs);
    },

    delete(endpoint, accessToken, body) {

        return this.request(endpoint, 'DELETE', accessToken, undefined, body);
    },

    /**
     * Catch errors from Microsoft API and set the message to something helpful
     * This message will be logged by Logstash and can be inspected on insights
     * @param {Function} asyncFunc
     * @param {string} [customMessage]
     * @return {Promise<*>}
     */
    async formatError(asyncFunc, customMessage = null) {
        try {
            return await asyncFunc();
        } catch (err) {
            /*
                Extract error message from response. According to the API docs,
                all error responses should follow this structure, but we keep this as a
                failsafe
             */
            const errMsg = (((err.error || {} ).error || {}).message || null);
            if (errMsg) {
                let message = err.error.error.message;
                if (customMessage && err.statusCode === 404) {
                    message = customMessage;
                }
                err.message = `${err.statusCode} - ${message}`;
            }
            throw err;
        }
    }
};
