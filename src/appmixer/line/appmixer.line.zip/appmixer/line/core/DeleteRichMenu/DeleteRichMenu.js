
const lib = require('../../lib.generated');
module.exports = {
    async receive(context) {
        const { richMenuId } = context.messages.in.content;

        // https://developers.line.biz/en/reference/messaging-api/#delete-rich-menu
        const { data } = await context.httpRequest({
            method: 'DELETE',
            url: 'https://api.line.me/v2/bot/richmenu/{richMenuId}',
            headers: {
                'Authorization': `Bearer ${context.auth.apiToken}`
            }
        });

        return context.sendJson(data, 'out');
    }
};
