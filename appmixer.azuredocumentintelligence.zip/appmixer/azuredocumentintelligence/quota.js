'use strict';

module.exports = {

    rules: []
};
